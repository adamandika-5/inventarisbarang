# Final Scan Success Feedback

Paket ini memakai potongan audio yang diunggah sebagai suara sukses scan. Audio
diputar satu kali per sesi, bersamaan dengan pola getaran `[200, 80, 200]` dan
banner nama barang.

## 1. Salin file

Salin kedua file berikut ke proyek dengan path yang sama:

- `public/sounds/scan-success.mp3`
- `src/lib/scan-success-feedback.ts`

File test opsional tetapi disarankan:

- `src/test/unit/scan-success-feedback.test.ts`

## 2. Tambahkan import dan state pada `scan-client.tsx`

```tsx
import { ScanSuccessFeedback } from '@/lib/scan-success-feedback'
```

Di dalam komponen:

```tsx
const scanFeedbackRef = useRef<ScanSuccessFeedback | null>(null)
const [scanToast, setScanToast] = useState<string | null>(null)
const [soundEnabled, setSoundEnabled] = useState(true)

const getScanFeedback = useCallback(() => {
  if (!scanFeedbackRef.current) {
    scanFeedbackRef.current = new ScanSuccessFeedback()
  }

  return scanFeedbackRef.current
}, [])

useEffect(() => {
  return () => {
    scanFeedbackRef.current?.dispose()
    scanFeedbackRef.current = null
  }
}, [])
```

## 3. Siapkan audio ketika pengguna memulai kamera

Letakkan ini pada awal handler tombol `Nyalakan Kamera`. Pemanggilan harus berasal
langsung dari klik/tap pengguna agar Chrome Android mengizinkan suara.

```tsx
const handleStartCamera = async () => {
  isProcessingScanRef.current = false
  setScanToast(null)

  await getScanFeedback().prepareForNewSession()

  // Pertahankan kode start kamera/scanner yang sudah ada di bawah sini.
}
```

Jika tombol `Scan Lagi` memiliki handler terpisah, arahkan ke handler start yang
sama. Jangan reset feedback di callback barcode.

## 4. Picu feedback segera setelah barang ditemukan

Di callback scan, pertahankan guard `isProcessingScanRef`. Setelah respons server
berhasil dan objek `item` sudah tersedia, jalankan feedback sebelum menunggu
cleanup kamera:

```tsx
// Barang sudah dipastikan ditemukan.
setSelectedItem(item)

if (getScanFeedback().triggerSuccess()) {
  setScanToast(`Barang ditemukan: ${item.name}`)
}

// Feedback di atas harus terjadi lebih dahulu.
await stopScannerAndCameraSafely()
```

Jangan panggil `triggerSuccess()` ketika barcode tidak dikenal, fetch gagal, atau
terjadi error jaringan. Jangan `await` pemutaran suara; helper sudah menangani
Promise dan error secara nonfatal.

## 5. Tampilkan banner

Letakkan di bagian atas kartu formulir barang:

```tsx
{scanToast ? (
  <div
    role="status"
    aria-live="polite"
    className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800"
  >
    {scanToast}
  </div>
) : null}
```

## 6. Tambahkan tombol suara

```tsx
const handleToggleSound = () => {
  const feedback = getScanFeedback()
  const nextValue = !feedback.isSoundEnabled()

  feedback.setSoundEnabled(nextValue)
  setSoundEnabled(nextValue)

  if (nextValue) {
    void feedback.primeAudio()
  }
}
```

```tsx
<button
  type="button"
  onClick={handleToggleSound}
  aria-pressed={soundEnabled}
  className="rounded-lg border px-3 py-2 text-sm font-medium"
>
  {soundEnabled ? 'Suara aktif' : 'Suara nonaktif'}
</button>
```

## 7. Verifikasi

```powershell
npm.cmd run type-check
npm.cmd run lint
npm.cmd test -- --run
npm.cmd run build
```

Uji dua transaksi berurutan di Android. Setiap sesi harus menghasilkan tepat satu
suara, satu pola getaran, dan satu banner. Volume media Android harus lebih dari
nol agar suara terdengar.
