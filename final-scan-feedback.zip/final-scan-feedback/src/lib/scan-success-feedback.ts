const DEFAULT_SOUND_URL = '/sounds/scan-success.mp3'
const DEFAULT_VIBRATION_PATTERN = [200, 80, 200]

export type ScanSuccessFeedbackOptions = {
  soundUrl?: string
  vibrationPattern?: number | number[]
}

/**
 * Mengelola suara dan getaran sukses scan tanpa mengikatnya ke library scanner.
 * Satu instance dipakai selama komponen scan masih terpasang.
 */
export class ScanSuccessFeedback {
  private readonly soundUrl: string
  private readonly vibrationPattern: number | number[]
  private audio: HTMLAudioElement | null = null
  private feedbackTriggered = false
  private soundEnabled = true
  private disposed = false

  constructor(options: ScanSuccessFeedbackOptions = {}) {
    this.soundUrl = options.soundUrl ?? DEFAULT_SOUND_URL
    this.vibrationPattern =
      options.vibrationPattern ?? [...DEFAULT_VIBRATION_PATTERN]
  }

  isSoundEnabled(): boolean {
    return this.soundEnabled
  }

  setSoundEnabled(enabled: boolean): void {
    this.soundEnabled = enabled

    if (!enabled && this.audio) {
      this.pauseAndRewind(this.audio)
    }
  }

  /** Reset hanya ketika kamera dimulai untuk barang berikutnya. */
  resetSession(): void {
    if (!this.disposed) {
      this.feedbackTriggered = false
    }
  }

  /**
   * Panggil langsung dari aksi pengguna, misalnya tombol "Nyalakan Kamera".
   * Pemutaran tanpa suara ini membantu membuka izin audio di browser seluler.
   */
  async primeAudio(): Promise<void> {
    if (!this.soundEnabled || this.disposed) return

    const audio = this.getAudio()
    if (!audio) return

    const previousMuted = audio.muted
    audio.muted = true

    try {
      audio.load()
      await audio.play()
    } catch {
      // Audio bersifat tambahan; kegagalannya tidak boleh merusak scanner.
    } finally {
      this.pauseAndRewind(audio)
      audio.muted = previousMuted
    }
  }

  /** Panggil pada awal setiap sesi scan baru. */
  async prepareForNewSession(): Promise<void> {
    this.resetSession()
    await this.primeAudio()
  }

  /**
   * Panggil segera setelah server memastikan barang ditemukan, sebelum cleanup
   * kamera ditunggu. Mengembalikan false untuk callback duplikat pada sesi sama.
   */
  triggerSuccess(): boolean {
    if (this.disposed || this.feedbackTriggered) return false

    this.feedbackTriggered = true
    this.vibrate()

    if (this.soundEnabled) {
      void this.playSound()
    }

    return true
  }

  dispose(): void {
    this.disposed = true
    this.feedbackTriggered = true

    if (this.audio) {
      this.pauseAndRewind(this.audio)
      this.audio = null
    }
  }

  private getAudio(): HTMLAudioElement | null {
    if (this.audio) return this.audio
    if (typeof Audio === 'undefined') return null

    const audio = new Audio(this.soundUrl)
    audio.preload = 'auto'
    this.audio = audio
    return audio
  }

  private async playSound(): Promise<void> {
    const audio = this.getAudio()
    if (!audio || this.disposed || !this.soundEnabled) return

    this.pauseAndRewind(audio)

    try {
      await audio.play()
    } catch {
      // Volume nol, kebijakan autoplay, atau browser tanpa audio tetap aman.
    }
  }

  private vibrate(): void {
    if (
      typeof navigator === 'undefined' ||
      typeof navigator.vibrate !== 'function'
    ) {
      return
    }

    try {
      navigator.vibrate(this.vibrationPattern)
    } catch {
      // Getaran tidak tersedia atau dinonaktifkan oleh perangkat.
    }
  }

  private pauseAndRewind(audio: HTMLAudioElement): void {
    try {
      audio.pause()
    } catch {
      // Abaikan kegagalan pause dari implementasi browser tertentu.
    }

    try {
      audio.currentTime = 0
    } catch {
      // Media mungkin belum memiliki metadata/seekable range.
    }
  }
}
