import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import { ScanSuccessFeedback } from '../../lib/scan-success-feedback'

class FakeAudio {
  static instances: FakeAudio[] = []

  readonly src: string
  preload = ''
  muted = false
  currentTime = 0
  load = vi.fn()
  pause = vi.fn()
  play = vi.fn<() => Promise<void>>().mockResolvedValue(undefined)

  constructor(src: string) {
    this.src = src
    FakeAudio.instances.push(this)
  }
}

describe('ScanSuccessFeedback', () => {
  const vibrate = vi.fn(() => true)

  beforeEach(() => {
    FakeAudio.instances = []
    vibrate.mockClear()
    vi.stubGlobal('Audio', FakeAudio)
    vi.stubGlobal('navigator', { vibrate })
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('memicu suara dan getaran hanya sekali dalam satu sesi', async () => {
    const feedback = new ScanSuccessFeedback()

    expect(feedback.triggerSuccess()).toBe(true)
    expect(feedback.triggerSuccess()).toBe(false)
    await Promise.resolve()

    expect(vibrate).toHaveBeenCalledTimes(1)
    expect(vibrate).toHaveBeenCalledWith([200, 80, 200])
    expect(FakeAudio.instances[0]?.play).toHaveBeenCalledTimes(1)
  })

  it('memberi feedback lagi setelah sesi di-reset', async () => {
    const feedback = new ScanSuccessFeedback()

    feedback.triggerSuccess()
    feedback.resetSession()
    feedback.triggerSuccess()
    await Promise.resolve()

    expect(vibrate).toHaveBeenCalledTimes(2)
    expect(FakeAudio.instances[0]?.play).toHaveBeenCalledTimes(2)
  })

  it('prepare sesi baru membuka audio dan mereset pengunci feedback', async () => {
    const feedback = new ScanSuccessFeedback()

    feedback.triggerSuccess()
    await feedback.prepareForNewSession()

    expect(feedback.triggerSuccess()).toBe(true)
    expect(FakeAudio.instances[0]?.load).toHaveBeenCalledTimes(1)
  })

  it('tidak error ketika play ditolak browser', async () => {
    const feedback = new ScanSuccessFeedback()
    feedback.triggerSuccess()

    const audio = FakeAudio.instances[0]
    expect(audio).toBeDefined()
    audio.play.mockRejectedValueOnce(new DOMException('Not allowed'))

    feedback.resetSession()
    expect(feedback.triggerSuccess()).toBe(true)
    await Promise.resolve()
    await Promise.resolve()
  })

  it('tetap aman ketika vibrate tidak tersedia', async () => {
    vi.stubGlobal('navigator', {})
    const feedback = new ScanSuccessFeedback()

    expect(feedback.triggerSuccess()).toBe(true)
    await Promise.resolve()

    expect(FakeAudio.instances[0]?.play).toHaveBeenCalledTimes(1)
  })

  it('dapat mematikan suara tanpa mematikan getaran', async () => {
    const feedback = new ScanSuccessFeedback()
    feedback.setSoundEnabled(false)

    expect(feedback.triggerSuccess()).toBe(true)
    await Promise.resolve()

    expect(vibrate).toHaveBeenCalledTimes(1)
    expect(FakeAudio.instances).toHaveLength(0)
  })
})
